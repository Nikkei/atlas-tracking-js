(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var _index = require('./index.js');

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var SDK_NAMESPACE = undefined || 'atlasTracking';
window[SDK_NAMESPACE] = new _index2.default();

},{"./index.js":2}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _utils = require('./utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var system = {};
var options = {};
var user = {};
var context = {};
var dataSrc = {};
var defaults = {};
var supplement = {};
var performanceInfo = {};
var atlasDOMContentLoadedHandler = null;
var targetWindow = window['parent'];
var visibilityEvent = null;
var unloadEvent = null;
var eventHandlerKeys = {
    unload: null,
    scroll: null,
    infinityScroll: null,
    read: null,
    click: null,
    viewability: {},
    media: {},
    form: {}
};

var pageLoadedAt = Date.now();
var prevActionOccurredAt = pageLoadedAt;

var AtlasTracking = function () {
    function AtlasTracking() {
        _classCallCheck(this, AtlasTracking);
    }

    /**
     * get current url's query value associated with argument.
     * @param  {string} k key of the query parameters.
     * @return {string}   value associated with the key.
     */


    _createClass(AtlasTracking, [{
        key: 'getQueryValue',
        value: function getQueryValue(k) {
            return this.utils.getQ(k) || '';
        }

        /**
         * get current cookie value associated with argument.
         * @param  {string} k key of the cookie value.
         * @return {string}   value associated with the key.
         */

    }, {
        key: 'getCookieValue',
        value: function getCookieValue(k) {
            return this.utils.getC(k) || '';
        }

        /**
         * get current localStorage value associated with argument.
         * @param  {string} k key of the localStorage index key.
         * @return {string}   value associated with the key.
         */

    }, {
        key: 'getLocalStorageValue',
        value: function getLocalStorageValue(k) {
            return this.utils.getLS(k) || '';
        }

        /**
         * store stringified JSON.
         * @param {string} s stringified JSON string.
         */

    }, {
        key: 'setDataSrc',
        value: function setDataSrc(s) {
            dataSrc = JSON.parse(decodeURIComponent(s));
        }

        /**
         * get value from Object stored by `setDataSrc`.
         * @param  {string} d key to fetch data.
         * @return {string|number|Object|Array|Boolean} fetched data.
         */

    }, {
        key: 'getDataFromSrc',
        value: function getDataFromSrc(d) {
            return dataSrc[d] || '';
        }

        /**
         * Inspect the element's visibility
         * @param  {HTMLElement} t element to be inspected.
         * @return {Object} inspection result.
         */

    }, {
        key: 'getVisibility',
        value: function getVisibility(t) {
            return this.utils.getV(t) || '';
        }

        /**
         * configure atlas tracking.
         * @param  {Object} obj configuration object.
         */

    }, {
        key: 'config',
        value: function config(obj) {

            system = obj.system !== void 0 ? obj.system : {};
            targetWindow = system.targetWindow ? window[system.targetWindow] : window['parent'];
            defaults.url = obj.defaults.pageUrl !== void 0 ? obj.defaults.pageUrl : targetWindow.document.location.href;
            defaults.referrer = obj.defaults.pageReferrer !== void 0 ? obj.defaults.pageReferrer : targetWindow.document.referrer;
            defaults.page_title = obj.defaults.pageTitle !== void 0 ? obj.defaults.pageTitle : targetWindow.document.title;
            defaults.product_family = obj.product.productFamily !== void 0 ? obj.product.productFamily : null;
            defaults.product = obj.product.productName !== void 0 ? obj.product.productName : null;

            this.utils = new _utils2.default(targetWindow);
            this.eventHandler = this.utils.handler();

            if ('onbeforeunload' in targetWindow) {
                unloadEvent = 'beforeunload';
            } else if ('onpagehide' in targetWindow) {
                unloadEvent = 'pagehide';
            } else {
                unloadEvent = 'unload';
            }

            try {
                visibilityEvent = new CustomEvent('atlasVisibilityStatus');
            } catch (e) {
                visibilityEvent = targetWindow.document.createEvent('CustomEvent');
                visibilityEvent.initCustomEvent('atlasVisibilityStatus', false, false, {});
            }
            var requestAnimationFrame = targetWindow.requestAnimationFrame || targetWindow.mozRequestAnimationFrame || targetWindow.webkitRequestAnimationFrame || targetWindow.msRequestAnimationFrame;

            if (requestAnimationFrame) {
                targetWindow.requestAnimationFrame = requestAnimationFrame;
            } else {
                var lastTime = 0;
                targetWindow.requestAnimationFrame = function (callback) {
                    var currTime = Date.now();
                    var timeToCall = Math.max(0, 16 - (currTime - lastTime));
                    var id = targetWindow.setTimeout(function () {
                        callback(currTime + timeToCall);
                    }, timeToCall);
                    lastTime = currTime + timeToCall;
                    return id;
                };
            }

            var timerFrequency = null;
            (function visibilityWatcher() {
                targetWindow.requestAnimationFrame(visibilityWatcher);
                if (timerFrequency) {
                    return false;
                }
                timerFrequency = setTimeout(function () {
                    targetWindow.dispatchEvent(visibilityEvent);
                    timerFrequency = null;
                }, 250);
            })();

            options = obj.options !== void 0 ? obj.options : {};
            this.utils.initSystem(system);
        }

        /**
         * set custom variable.
         * @param {string} k                     key of the variable.
         * @param {Object|string|number\Array|Boolean} o variable to be set.
         */

    }, {
        key: 'setCustomVars',
        value: function setCustomVars(k, o) {
            context[k] = o;
        }

        /**
         * set custom object in ingest.context.custom_object
         * @param {string} k key of the object.
         * @param {Object} o object to be set.
         */

    }, {
        key: 'setCustomObject',
        value: function setCustomObject(k, o) {
            context.custom_object[k] = o;
        }

        /**
         * set user id of external tools(e.g. rtoaster).
         * @param {string} k key of the user id.
         * @param {string} o user id to be set.
         */

    }, {
        key: 'setCustomId',
        value: function setCustomId(k, o) {
            user.external_ids[k] = o;
        }

        /**
         * delete custome variable set by `setCustomVars`.
         * @param  {string} k key of the variable.
         */

    }, {
        key: 'delCustomVars',
        value: function delCustomVars(k) {
            delete context[k];
        }

        /**
         * delete custom object set by `setCustomObject`.
         * @param  {string} k key of the custom object.
         */

    }, {
        key: 'delCustomObject',
        value: function delCustomObject(k) {
            delete context.custom_object[k];
        }

        /**
         * delete custom user id set by `setCustomId`.
         * @param  {string} k key of the object.
         */

    }, {
        key: 'delCustomId',
        value: function delCustomId(k) {
            delete user.external_ids[k];
        }

        /**
         * re-attach event listeners to DOMs.
         */

    }, {
        key: 'initEventListeners',
        value: function initEventListeners() {
            var _this = this;

            if (options.trackClick && options.trackClick.enable || options.trackLink && options.trackLink.enable || options.trackDownload && options.trackDownload.enable) {
                this.delegateClickEvents({
                    'trackClick': options.trackClick,
                    'trackLink': options.trackLink,
                    'trackDownload': options.trackDownload
                });
            }
            if (options.trackUnload && options.trackUnload.enable) {
                this.setEventToUnload();
            }
            if (options.trackScroll && options.trackScroll.enable) {
                this.trackScroll(options.trackScroll.granularity, options.trackScroll.threshold);
            }
            if (options.trackInfinityScroll && options.trackInfinityScroll.enable) {
                this.trackInfinityScroll(options.trackInfinityScroll.step, options.trackInfinityScroll.threshold);
            }
            if (options.trackRead && options.trackRead.enable) {
                this.trackRead(options.trackRead.target, options.trackRead.granularity, options.trackRead.milestones);
            }
            if (options.trackViewability && options.trackViewability.enable) {
                this.trackViewability(options.trackViewability.targets);
            }
            if (options.trackMedia && options.trackMedia.enable) {
                this.trackMedia(options.trackMedia.selector, options.trackMedia.heartbeat);
            }
            if (options.trackForm && options.trackForm.enable) {
                this.trackForm(options.trackForm.target);
            }
            if (options.trackPerformance && options.trackPerformance.enable) {
                atlasDOMContentLoadedHandler = function atlasDOMContentLoadedHandler() {
                    performanceInfo = _this.utils.getP();
                    context.navigation_timing = performanceInfo.performanceResult || {};
                    context.navigation_type = performanceInfo.navigationType || {};
                };
                targetWindow.addEventListener('DOMContentLoaded', atlasDOMContentLoadedHandler, false);
            }
            if (options.trackThroughMessage && options.trackThroughMessage.enable) {
                this.trackThroughMessage();
            }
        }

        /**
         * initialize atlas tracking per page.
         * @param  {Object} obj initialization config object.
         */

    }, {
        key: 'initPage',
        value: function initPage(obj) {
            if (obj.user !== void 0) {
                user = {
                    'user_id': obj.user.user_id || undefined,
                    'user_status': obj.user.user_status || undefined,
                    'site_session': obj.user.site_session || undefined,
                    'external_ids': {},
                    'custom_object': obj.user.custom_object || {},
                    'federation_id': obj.user.federation_id || undefined
                };
            }
            if (obj.context !== void 0) {
                context = {
                    'root_id': this.utils.getUniqueId(),
                    'url': obj.context.url !== void 0 ? obj.context.url : defaults.url,
                    'referrer': obj.context.referrer !== void 0 ? obj.context.referrer : defaults.referrer,
                    'product_family': obj.context.product_family !== void 0 ? obj.context.product_family : defaults.product_family,
                    'product': obj.context.product || defaults.product,
                    'app': obj.context.app || undefined,
                    'app_version': obj.context.app_version || undefined,
                    'page_title': obj.context.page_title || defaults.page_title,
                    'source': obj.context.source || undefined,
                    'edition': obj.context.edition || undefined,
                    'content_id': obj.context.content_id || undefined,
                    'content_name': obj.context.content_name || undefined,
                    'content_status': obj.context.content_status || undefined,
                    'page_name': obj.context.page_name || undefined,
                    'page_num': obj.context.page_num || 1,
                    'category_l1': obj.context.category_l1 || undefined,
                    'category_l2': obj.context.category_l2 || undefined,
                    'category_l3': obj.context.category_l3 || undefined,
                    'tracking_code': obj.context.tracking_code || undefined,
                    'campaign': obj.context.campaign || undefined,
                    'search': obj.context.search || undefined,
                    'events': obj.context.events || undefined,
                    'custom_object': obj.context.custom_object || {},
                    'funnel': obj.context.funnel || {},
                    'visibility': targetWindow.document.visibilityState || 'unknown'
                };
            }
            if (options.trackNavigation && options.trackNavigation.enable) {
                context.navigation = this.utils.getNav() || {};
            }
            if (options.trackPerformance && options.trackPerformance.enable) {
                performanceInfo = this.utils.getP();
                context.navigation_timing = performanceInfo.performanceResult || {};
                context.navigation_type = performanceInfo.navigationType || {};
            }

            this.initEventListeners();
        }

        /**
         * remove tracking options and handlers
         */

    }, {
        key: 'disableTracking',
        value: function disableTracking() {
            if (options.trackClick && options.trackClick.enable || options.trackLink && options.trackLink.enable || options.trackDownload && options.trackDownload.enable) {
                this.eventHandler.remove(eventHandlerKeys['click']);
            }
            if (options.trackUnload && options.trackUnload.enable) {
                this.eventHandler.remove(eventHandlerKeys['unload']);
            }
            if (options.trackScroll && options.trackScroll.enable) {
                this.eventHandler.remove(eventHandlerKeys['scroll']);
            }
            if (options.trackInfinityScroll && options.trackInfinityScroll.enable) {
                this.eventHandler.remove(eventHandlerKeys['infinityScroll']);
            }
            if (options.trackRead && options.trackRead.enable) {
                this.eventHandler.remove(eventHandlerKeys['read']);
            }
            if (options.trackViewability && options.trackViewability.enable) {
                this.eventHandler.remove(eventHandlerKeys['viewability']);
            }
            if (options.trackMedia && options.trackMedia.enable) {
                var targetEvents = ['play', 'pause', 'end'];
                var _iteratorNormalCompletion = true;
                var _didIteratorError = false;
                var _iteratorError = undefined;

                try {
                    for (var _iterator = targetEvents[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                        var event = _step.value;

                        this.eventHandler.remove(eventHandlerKeys['media'][event]);
                    }
                } catch (err) {
                    _didIteratorError = true;
                    _iteratorError = err;
                } finally {
                    try {
                        if (!_iteratorNormalCompletion && _iterator.return) {
                            _iterator.return();
                        }
                    } finally {
                        if (_didIteratorError) {
                            throw _iteratorError;
                        }
                    }
                }
            }
            if (options.trackForm && options.trackForm.enable && options.trackForm.target !== null) {
                var _targetEvents = ['focus', 'change'];
                var _iteratorNormalCompletion2 = true;
                var _didIteratorError2 = false;
                var _iteratorError2 = undefined;

                try {
                    for (var _iterator2 = _targetEvents[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                        var _event = _step2.value;

                        this.eventHandler.remove(eventHandlerKeys['form'][_event]);
                    }
                } catch (err) {
                    _didIteratorError2 = true;
                    _iteratorError2 = err;
                } finally {
                    try {
                        if (!_iteratorNormalCompletion2 && _iterator2.return) {
                            _iterator2.return();
                        }
                    } finally {
                        if (_didIteratorError2) {
                            throw _iteratorError2;
                        }
                    }
                }
            }
            if (options.trackPerformance && options.trackPerformance.enable) {
                targetWindow.removeEventListener('DOMContentLoaded', atlasDOMContentLoadedHandler);
            }

            options = {};
        }

        /**
         * track page view.
         */

    }, {
        key: 'trackPage',
        value: function trackPage() {
            this.utils.transmit('view', 'page', user, context, supplement);
        }

        /**
         * Send any data at any timing.
         * @param  {string} [action='action']    describes how user interact.
         * @param  {string} [category='unknown'] what the action parameter's subject.
         * @param  {string} [events=null]        describes what happened by the user's action.
         * @param  {Object} [obj={}]             custom variables.
         */

    }, {
        key: 'trackAction',
        value: function trackAction() {
            var action = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'action';
            var category = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'unknown';
            var events = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            var obj = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

            var now = Date.now();
            context.events = events || null;
            this.utils.transmit(action, category, user, context, {
                'action': {
                    'location': obj.location || undefined,
                    'destination': obj.destination || undefined,
                    'dataset': obj.dataset || undefined,
                    'name': obj.action_name || undefined,
                    'elapsed_since_page_load': (now - pageLoadedAt) / 1000,
                    'elapsed_since_prev_action': (now - prevActionOccurredAt) / 1000,
                    'content_id': obj.content_id || undefined,
                    'content_name': obj.content_name || undefined,
                    'custom_vars': obj.custom_vars || {}
                }
            });
            context.events = null;
            prevActionOccurredAt = now;
        }

        /**
         * @private
         */

    }, {
        key: 'delegateClickEvents',
        value: function delegateClickEvents(obj) {
            var _this2 = this;

            this.eventHandler.remove(eventHandlerKeys['click']);
            eventHandlerKeys['click'] = this.eventHandler.add(targetWindow.document.body, 'click', function (ev) {
                var targetAttribute = obj.trackClick && obj.trackClick.targetAttribute ? obj.trackClick.targetAttribute : false;
                var targetElement = _this2.utils.qsM('a, button, [role="button"]', ev.target, targetAttribute);

                if (targetElement && targetElement.element) {

                    var elm = targetElement.element;
                    var ext = (elm.pathname || '').match(/.+\/.+?\.([a-z]+([?#;].*)?$)/);
                    var attr = {
                        'destination': elm.href || undefined,
                        'dataset': elm.dataset || undefined,
                        'target': elm.target || undefined,
                        'media': elm.media || undefined,
                        'type': elm.type || undefined,
                        'tag': elm.tagName.toLowerCase(),
                        'id': elm.id || undefined,
                        'class': elm.className || undefined,
                        'text': (elm.innerText || elm.value || '').substr(0, 63) || undefined,
                        'elapsed_since_page_load': (Date.now() - pageLoadedAt) / 1000
                    };

                    // Outbound
                    if (obj.trackLink && obj.trackLink.enable && elm.hostname && targetWindow.location.hostname !== elm.hostname && obj.trackLink.internalDomains.indexOf(elm.hostname) < 0) {
                        _this2.utils.transmit('open', 'outbound_link', user, context, {
                            'link': Object.assign(attr, {
                                'location': targetElement.pathDom,
                                'name': obj.trackLink.nameAttribute ? elm.getAttribute(obj.trackLink.nameAttribute) : undefined
                            })
                        });
                    }

                    // Download
                    if (obj.trackDownload && obj.trackDownload.enable && elm.hostname && ext && obj.trackDownload.fileExtensions.indexOf(ext[1]) >= 0) {
                        _this2.utils.transmit('download', 'file', user, context, {
                            'download': Object.assign(attr, {
                                'location': targetElement.pathDom,
                                'name': obj.trackLink.nameAttribute ? elm.getAttribute(obj.trackDownload.nameAttribute) : undefined
                            })
                        });
                    }

                    // Click
                    if (obj.trackClick && obj.trackClick.enable && targetElement) {
                        if (!obj.trackClick.targetAttribute) {
                            _this2.utils.transmit('click', targetElement.category, user, context, {
                                'action': Object.assign(attr, {
                                    'location': targetElement.pathDom,
                                    'name': undefined
                                })
                            });
                        } else {
                            if (targetElement.pathTrackable.length > 0) {
                                _this2.utils.transmit('click', targetElement.category, user, context, {
                                    'action': Object.assign(attr, {
                                        'location': targetElement.pathTrackable,
                                        'name': elm.getAttribute(targetAttribute)
                                    })
                                });
                            }
                        }
                    }
                }
            }, false);
        }

        /**
         * @private
         */

    }, {
        key: 'setEventToUnload',
        value: function setEventToUnload() {
            var _this3 = this;

            this.eventHandler.remove(eventHandlerKeys['unload']);
            eventHandlerKeys['unload'] = this.eventHandler.add(targetWindow, unloadEvent, function () {
                _this3.utils.transmit('unload', 'page', user, context, {
                    'action': {
                        'name': 'leave_from_page',
                        'elapsed_since_page_load': (Date.now() - pageLoadedAt) / 1000
                    }
                });
            }, false);
        }

        /**
         * @private
         */

    }, {
        key: 'trackScroll',
        value: function trackScroll(granularity, threshold) {
            var _this4 = this;

            var each = granularity || 25;
            var steps = 100 / each;
            var limit = threshold * 1000 || 2 * 1000;
            var now = Date.now();
            var prev = now;
            var r = {}; //result
            var cvr = 0; //currentViewRate
            var pvr = 0; //prevViewRate
            this.eventHandler.remove(eventHandlerKeys['scroll']);
            eventHandlerKeys['scroll'] = this.eventHandler.add(targetWindow, 'atlasVisibilityStatus', function () {
                r = _this4.utils.getV(null);
                if (r.detail.documentIsVisible !== 'hidden' && r.detail.documentIsVisible !== 'prerender') {
                    now = Date.now();
                    cvr = Math.round(r.detail.documentScrollRate * steps) * each;
                    if (cvr > pvr && cvr >= 0 && cvr <= 100) {
                        setTimeout(function () {
                            if (cvr > pvr) {
                                _this4.utils.transmit('scroll', 'page', user, context, {
                                    'scroll_depth': {
                                        'page_height': r.detail.documentHeight,
                                        'viewed_until': r.detail.documentScrollUntil,
                                        'viewed_percent': cvr,
                                        'elapsed_since_page_load': (now - pageLoadedAt) / 1000,
                                        'elapsed_since_prev_action': (now - prev) / 1000
                                    }
                                });
                                pvr = cvr;
                            }
                            prev = now;
                        }, limit);
                    }
                }
            }, false);
        }

        /**
         * @private
         */

    }, {
        key: 'trackInfinityScroll',
        value: function trackInfinityScroll(step, threshold) {
            var _this5 = this;

            var limit = threshold * 1000 || 2 * 1000;
            var now = Date.now();
            var prev = now;
            var r = {}; //result
            var cvp = 0; //currentViewRate
            var pvp = 0; //prevViewRate
            this.eventHandler.remove(eventHandlerKeys['infinityScroll']);
            eventHandlerKeys['infinityScroll'] = this.eventHandler.add(targetWindow, 'atlasVisibilityStatus', function () {
                r = _this5.utils.getV(null);
                if (r.detail.documentIsVisible !== 'hidden' && r.detail.documentIsVisible !== 'prerender') {
                    now = Date.now();
                    cvp = r.detail.documentScrollUntil;
                    if (cvp > pvp && cvp >= pvp && cvp >= step) {
                        setTimeout(function () {
                            if (cvp > pvp) {
                                _this5.utils.transmit('infinity_scroll', 'page', user, context, {
                                    'scroll_depth': {
                                        'page_height': r.detail.documentHeight,
                                        'viewed_until': cvp,
                                        'viewed_percent': r.detail.documentScrollRate,
                                        'elapsed_since_page_load': (now - pageLoadedAt) / 1000,
                                        'elapsed_since_prev_action': (now - prev) / 1000
                                    }
                                });
                                pvp = cvp + step;
                            }
                            prev = now;
                        }, limit);
                    }
                }
            }, false);
        }

        /**
         * @private
         */

    }, {
        key: 'trackRead',
        value: function trackRead(target, granularity) {
            var _this6 = this;

            var milestones = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];

            if (!target) {
                return;
            }
            var each = granularity || 25;
            var steps = 100 / each;
            var now = Date.now();
            var prev = now;
            var r = {}; //result
            var eiv = 0; //elapsedInVisible
            var cvr = 0; //currentViewRate
            var pvr = 0; //prevViewRate
            this.eventHandler.remove(eventHandlerKeys['read']);
            eventHandlerKeys['read'] = this.eventHandler.add(targetWindow, 'atlasVisibilityStatus', function () {
                r = _this6.utils.getV(target);
                if (r.detail.documentIsVisible !== 'hidden' && r.detail.documentIsVisible !== 'prerender' && r.status.isInView) {
                    now = Date.now();
                    if (now - prev >= 1000) {
                        prev = now;
                    }
                    eiv = eiv + (now - prev);
                    prev = now;

                    // Milestone based
                    if (milestones.length > 0 && milestones[0] <= eiv / 1000) {
                        _this6.utils.transmit('read', 'article', user, context, {
                            'read': {
                                'mode': 'time',
                                'milestone': milestones[0],
                                'page_height': r.detail.documentHeight,
                                'element_height': r.detail.targetHeight,
                                'viewed_from': r.detail.targetVisibleTop,
                                'viewed_until': r.detail.targetVisibleBottom,
                                'viewed_percent': cvr,
                                'elapsed_since_page_load': (now - pageLoadedAt) / 1000,
                                'elapsed_since_prev_action': (now - prev) / 1000
                            }
                        });
                        milestones.shift();
                    }

                    // Scroll based
                    cvr = Math.round(r.detail.targetScrollRate * steps) * each;
                    if (cvr > pvr && cvr >= 0 && cvr <= 100) {
                        setTimeout(function () {
                            if (cvr > pvr) {
                                _this6.utils.transmit('read', 'article', user, context, {
                                    'read': {
                                        'mode': 'scroll',
                                        'page_height': r.detail.documentHeight,
                                        'element_height': r.detail.targetHeight,
                                        'viewed_from': r.detail.targetVisibleTop,
                                        'viewed_until': r.detail.targetVisibleBottom,
                                        'viewed_percent': cvr,
                                        'elapsed_since_page_load': (now - pageLoadedAt) / 1000,
                                        'elapsed_since_prev_action': (now - prev) / 1000
                                    }
                                });
                                pvr = cvr;
                            }
                        }, 1000);
                    }
                }
            }, false);
        }

        /**
         * @private
         */

    }, {
        key: 'trackViewability',
        value: function trackViewability(targets) {
            var _this7 = this;

            var now = Date.now();
            var r = {}; //results
            var f = {}; //flags
            this.eventHandler.remove(eventHandlerKeys['viewability']);
            eventHandlerKeys['viewability'] = this.eventHandler.add(targetWindow, 'atlasVisibilityStatus', function () {
                var _loop = function _loop(i) {
                    if (targets[i]) {
                        r[i] = _this7.utils.getV(targets[i]);
                        if (r[i].status.isInView === true && r[i].detail.documentIsVisible !== 'hidden' && r[i].detail.documentIsVisible !== 'prerender' && r[i].detail.targetViewableRate >= 0.5 && !f[i]) {
                            setTimeout(function () {
                                if (r[i].detail.targetViewableRate >= 0.5 && !f[i]) {
                                    now = Date.now();
                                    f[i] = true;
                                    _this7.utils.transmit('viewable_impression', 'ad', user, context, {
                                        'viewability': {
                                            'page_height': r[i].detail.documentHeight,
                                            'element_order_in_target': i,
                                            'element_tag': targets[i].tagName,
                                            'element_class': targets[i].className,
                                            'element_id': targets[i].id,
                                            'element_height': r[i].detail.targetHeight,
                                            'elapsed_since_page_load': (now - pageLoadedAt) / 1000
                                        }
                                    });
                                }
                            }, 1000);
                        }
                    }
                };

                for (var i = 0; i < targets.length; i++) {
                    _loop(i);
                }
            }, false);
        }

        /**
         * @private
         */

    }, {
        key: 'trackMedia',
        value: function trackMedia(selector, heartbeat) {
            var _this8 = this;

            var targetEvents = ['play', 'pause', 'end'];
            var f = {}; //flags

            var _loop2 = function _loop2(i) {
                _this8.eventHandler.remove(eventHandlerKeys['media'][targetEvents[i]]);
                eventHandlerKeys['media'][targetEvents[i]] = _this8.eventHandler.add(targetWindow.document.body, targetEvents[i], function (ev) {
                    if (_this8.utils.qsM(selector, ev.target)) {
                        var details = _this8.utils.getM(ev.target);
                        _this8.utils.transmit(targetEvents[i], details.tag, user, context, {
                            'media': details
                        });
                    }
                }, { capture: true });
            };

            for (var i = 0; i < targetEvents.length; i++) {
                _loop2(i);
            }

            this.eventHandler.remove(eventHandlerKeys['media']['timeupdate']);
            eventHandlerKeys['media']['timeupdate'] = this.eventHandler.add(targetWindow.document, 'timeupdate', function (ev) {
                if (_this8.utils.qsM(selector, ev.target)) {
                    var details = _this8.utils.getM(ev.target);
                    var index = details.tag + '-' + details.id + '-' + details.src;
                    if (f[index]) {
                        return false;
                    }
                    f[index] = setTimeout(function () {
                        if (ev.target.paused !== true && ev.target.ended !== true) {
                            _this8.utils.transmit('playing', details.tag, user, context, {
                                'media': details
                            });
                        }
                        f[index] = false;
                    }, heartbeat * 1000);
                }
            }, { capture: true });
        }
    }, {
        key: 'trackForm',
        value: function trackForm(target) {
            var _this9 = this;

            if (!target) {
                return;
            }
            var targetEvents = ['focus', 'change'];
            var f = {
                'name': target.name || target.id || '-',
                'dataset': target.dataset,
                'items_detail': {}
            };

            var _loop3 = function _loop3(i) {
                _this9.eventHandler.remove(eventHandlerKeys['form'][targetEvents[i]]);
                eventHandlerKeys['form'][targetEvents[i]] = _this9.eventHandler.add(target, targetEvents[i], function (ev) {
                    f = _this9.utils.getF(f, targetEvents[i], ev.target, pageLoadedAt);
                }, false);
            };

            for (var i = 0; i < targetEvents.length; i++) {
                _loop3(i);
            }
            this.eventHandler.remove(eventHandlerKeys['unload']);
            eventHandlerKeys['unload'] = this.eventHandler.add(targetWindow, unloadEvent, function () {
                _this9.utils.transmit('track', 'form', user, context, {
                    'form': f
                });
            }, false);
        }
    }, {
        key: 'trackThroughMessage',
        value: function trackThroughMessage() {
            var _this10 = this;

            this.eventHandler.remove(eventHandlerKeys['message']);
            eventHandlerKeys['message'] = this.eventHandler.add(targetWindow, 'message', function (msg) {
                var attributes = {};
                try {
                    attributes = JSON.parse(msg.data.attributes);
                } catch (e) {}
                if (msg && msg.data && msg.data.isAtlasEvent) {
                    _this10.utils.transmit(msg.data.action, msg.data.category, user, context, attributes);
                }
            }, false);
        }
    }]);

    return AtlasTracking;
}();

exports.default = AtlasTracking;

},{"./utils.js":3}],3:[function(require,module,exports){
'use strict';

// SDK Version Info

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var SDK_NAME = 'ATJ';
var SDK_VERSION = '2.15.8';
var SDK_API_KEY = undefined || 'test_api_key';
var DEFAULT_ENDPOINT = undefined || 'atlas.local';

var atlasEndpoint = null;
var atlasApiKey = null;
var atlasBeaconTimeout = null;
var atlasCookieName = null;
var atlasId = '0';
var handlerEvents = {};
var handlerKey = 0;
var sendBeaconStatus = true;

/**
 * @ignore
 */

var Utils = function () {
    function Utils(targetWindow) {
        _classCallCheck(this, Utils);

        var timestamp = (+new Date()).toString(16);
        var u32a = new Uint32Array(3);
        var result = '';
        self.crypto.getRandomValues(u32a);
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
            for (var _iterator = u32a[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var num = _step.value;

                result += num.toString(32);
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally {
            try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                    _iterator.return();
                }
            } finally {
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }

        this.uniqueId = timestamp + '.' + result;
        this.targetWindow = targetWindow;
    }

    _createClass(Utils, [{
        key: 'initSystem',
        value: function initSystem(system) {
            atlasEndpoint = system.endpoint ? system.endpoint : DEFAULT_ENDPOINT;
            atlasApiKey = system.apiKey ? system.apiKey : SDK_API_KEY;
            atlasBeaconTimeout = system.beaconTimeout ? system.beaconTimeout : 2000;
            atlasCookieName = system.cookieName ? system.cookieName : 'atlasId';

            atlasId = this.getC(atlasCookieName);

            if (!atlasId || atlasId === '0' || atlasId === 0 || atlasId === '1' || atlasId === 1 || atlasId.length < 5) {
                atlasId = this.uniqueId;
            }
        }
    }, {
        key: 'qsM',
        value: function qsM(s, t) {
            var d = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

            var e = null; // Trackable Element
            var c = 'button';
            var pt = []; // Path of data-trackable
            var pd = []; // Path of elements
            if (t.nodeType === 3) {
                t = t.parentNode;
            }
            while (t && t !== this.targetWindow.document) {
                var matches = (t.matches || t.msMatchesSelector || function () {
                    return false;
                }).bind(t);

                var elm = t.tagName.toLowerCase();
                if (elm !== 'html' && elm !== 'body') {
                    if (t.id) {
                        elm += '#' + t.id;
                    }
                    if (t.className) {
                        elm += '.' + t.className;
                    }
                    pd.unshift(elm);
                }

                if (d) {
                    if (t.hasAttribute(d)) {
                        pt.unshift(t.getAttribute(d));
                    }
                }

                if (!e && matches(s)) {
                    if (t.tagName.toLowerCase() === 'a') {
                        c = 'link';
                    } else {
                        c = t.tagName.toLowerCase();
                    }
                    e = t;
                }

                t = t.parentNode;
            }

            return {
                'element': e,
                'category': c,
                'pathTrackable': pt.join('>'),
                'pathDom': pd.join('>')
            };
        }
    }, {
        key: 'getC',
        value: function getC(k) {
            var cookies = this.targetWindow.document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i];
                while (cookie.charAt(0) === ' ') {
                    cookie = cookie.substring(1, cookie.length);
                }
                if (cookie.indexOf(k + '=') === 0) {
                    return cookie.substring((k + '=').length, cookie.length);
                }
            }
            return '';
        }
    }, {
        key: 'getQ',
        value: function getQ(k) {
            var s = this.targetWindow.location.search.slice(1);
            if (s === '') {
                return '';
            }
            var q = s.split('&');
            var l = q.length;
            for (var i = 0; i < l; ++i) {
                var pair = q[i].split('=');
                if (decodeURIComponent(pair[0]) === k) {
                    return decodeURIComponent(pair[1]);
                }
            }
            return '';
        }
    }, {
        key: 'getLS',
        value: function getLS(k) {
            var r = '';
            try {
                r = this.targetWindow.localStorage[k];
            } catch (e) {
                r = '';
            }
            return r;
        }
    }, {
        key: 'getNav',
        value: function getNav() {
            var nav = {
                history_length: this.targetWindow.history.length
            };
            if ('performance' in this.targetWindow) {
                var p = this.targetWindow.performance;
                if ('getEntriesByType' in p) {
                    var navs = p.getEntriesByType('navigation');
                    if (navs.length >= 1) {
                        nav.type = navs[0].type;
                        nav.redirectCount = navs[0].redirectCount;
                        nav.domContentLoaded = navs[0].domContentLoadedEventStart;
                    }
                }
                if ('getEntriesByName' in p) {
                    var paints = p.getEntriesByName('first-paint');
                    if (paints.length >= 1) {
                        nav.first_paint = paints[0].startTime;
                    }
                }
            }
            return nav;
        }
    }, {
        key: 'getP',
        value: function getP() {
            var p = {}; // Performance Timing
            var t = {}; // Navigation Type
            var r = {}; // Result
            if ('performance' in this.targetWindow) {
                p = this.targetWindow.performance.timing;
                r = {
                    'unload': p.unloadEventEnd - p.unloadEventStart < 0 || p.unloadEventEnd - p.unloadEventStart > 3600000 ? null : p.unloadEventEnd - p.unloadEventStart,
                    'redirect': p.redirectEnd - p.redirectStart < 0 || p.redirectEnd - p.redirectStart > 3600000 ? null : p.redirectEnd - p.redirectStart,
                    'dns': p.domainLookupEnd - p.domainLookupStart < 0 || p.domainLookupEnd - p.domainLookupStart > 3600000 ? null : p.domainLookupEnd - p.domainLookupStart,
                    'tcp': p.connectEnd - p.connectStart < 0 || p.connectEnd - p.connectStart > 3600000 ? null : p.connectEnd - p.connectStart,
                    'request': p.responseStart - p.requestStart < 0 || p.responseStart - p.requestStart > 3600000 ? null : p.responseStart - p.requestStart,
                    'response': p.responseEnd - p.responseStart < 0 || p.responseEnd - p.responseStart > 3600000 ? null : p.responseEnd - p.responseStart,
                    'dom': p.domContentLoadedEventStart - p.domLoading < 0 || p.domContentLoadedEventStart - p.domLoading > 3600000 ? null : p.domContentLoadedEventStart - p.domLoading,
                    'domContent': p.domContentLoadedEventEnd - p.domContentLoadedEventStart < 0 || p.domContentLoadedEventEnd - p.domContentLoadedEventStart > 3600000 ? null : p.domContentLoadedEventEnd - p.domContentLoadedEventStart,
                    'onload': p.loadEventEnd - p.loadEventStart < 0 || p.loadEventEnd - p.loadEventStart > 3600000 ? null : p.loadEventEnd - p.loadEventStart,
                    'untilResponseComplete': p.responseEnd - p.navigationStart < 0 || p.responseEnd - p.navigationStart > 3600000 ? null : p.responseEnd - p.navigationStart,
                    'untilDomComplete': p.domContentLoadedEventStart - p.navigationStart < 0 || p.domContentLoadedEventStart - p.navigationStart > 3600000 ? null : p.domContentLoadedEventStart - p.navigationStart
                };
                t = (this.targetWindow.performance || {}).navigation;
            }
            return {
                'performanceResult': r,
                'navigationType': t
            };
        }
    }, {
        key: 'handler',
        value: function handler() {
            return {
                add: function add(target, type, listener, capture) {
                    target.addEventListener(type, listener, capture);
                    handlerEvents[handlerKey] = {
                        target: target,
                        type: type,
                        listener: listener,
                        capture: capture
                    };
                    return handlerKey++;
                },
                remove: function remove(handlerKey) {
                    if (handlerKey in handlerEvents) {
                        var e = handlerEvents[handlerKey];
                        e.target.removeEventListener(e.type, e.listener, e.capture);
                    }
                }
            };
        }
    }, {
        key: 'getV',
        value: function getV(t) {
            var tgr = {}; //targetRect
            try {
                tgr = t.getBoundingClientRect();
            } catch (e) {
                tgr = {};
            }

            var vph = this.targetWindow.innerHeight; //viewportHeight
            var dch = this.targetWindow.document.documentElement.scrollHeight; //documentHeight
            var div = this.targetWindow.document.visibilityState || 'unknown'; //documentIsVisible
            var dvt = 'pageYOffset' in this.targetWindow ? this.targetWindow.pageYOffset : (this.targetWindow.document.documentElement || this.targetWindow.document.body.parentNode || this.targetWindow.document.body).scrollTop; //documentVisibleTop
            var dvb = dvt + vph; //documentVisibleBottom
            var tgh = tgr.height; //targetHeight
            var tmt = tgr.top <= 0 ? 0 : tgr.top; //targetMarginTop
            var tmb = (tgr.bottom - vph) * -1 <= 0 ? 0 : (tgr.bottom - vph) * -1; //targetMarginBottom
            var dsu = dvb; //documentScrollUntil
            var dsr = dvb / dch; //documentScrollRate

            var tvt = null; //targetVisibleTop
            var tvb = null; //targetVisibleBottom
            var tsu = 0; //targetScrollUntil
            var tsr = 0; //targetScrollRate
            var tvr = 0; //targetViewableRate
            var iiv = false; //isInView
            var loc = null; //location

            if (tgr.top >= 0 && tgr.bottom > vph && tgr.top >= vph) {
                // pre
                tvt = null;
                tvb = null;
                iiv = false;
                loc = 'pre';
            } else if (tgr.top >= 0 && tgr.bottom > vph && tgr.top < vph) {
                // top
                tvt = 0;
                tvb = vph - tgr.top;
                iiv = true;
                loc = 'top';
            } else if (tgr.top < 0 && tgr.bottom > vph) {
                // middle
                tvt = tgr.top * -1;
                tvb = tvt + vph;
                iiv = true;
                loc = 'middle';
            } else if (tgr.top >= 0 && tgr.bottom <= vph) {
                // all in
                tvt = 0;
                tvb = tgh;
                iiv = true;
                loc = 'all';
            } else if (tgr.top < 0 && tgr.bottom >= 0 && tgr.bottom <= vph) {
                // bottom
                tvt = tgh + tgr.top;
                tvb = tgh;
                iiv = true;
                loc = 'bottom';
            } else if (tgr.top < 0 && tgr.bottom < 0) {
                // post
                tvt = null;
                tvb = null;
                iiv = false;
                loc = 'post';
            } else {
                iiv = false;
                loc = 'unknown';
            }

            tvr = (tvb - tvt) / tgh;
            tsu = tvb;
            tsr = tsu / tgh;

            return {
                'detail': {
                    'viewportHeight': vph,
                    'documentHeight': dch,
                    'documentIsVisible': div,
                    'documentVisibleTop': dvt,
                    'documentVisibleBottom': dvb,
                    'targetHeight': tgh,
                    'targetVisibleTop': tvt,
                    'targetVisibleBottom': tvb,
                    'targetMarginTop': tmt,
                    'targetMarginBottom': tmb,
                    'targetScrollUntil': tsu,
                    'targetScrollRate': tsr,
                    'targetViewableRate': tvr,
                    'documentScrollUntil': dsu,
                    'documentScrollRate': dsr
                },
                'status': {
                    'isInView': iiv,
                    'location': loc
                }
            };
        }
    }, {
        key: 'getM',
        value: function getM(t) {
            if (t !== void 0) {
                return {
                    'tag': t.nodeName.toLowerCase() || 'na',
                    'id': t.id || 'na',
                    'src': t.src || 'na',
                    'type': t.type || undefined,
                    'codecs': t.codecs || undefined,
                    'muted': t.muted || false,
                    'default_muted': t.defaultMuted || false,
                    'autoplay': t.autoplay || false,
                    'width': t.clientWidth || undefined,
                    'height': t.clientHeight || undefined,
                    'player_id': t.playerId || undefined,
                    'played_percent': Math.round(t.currentTime / t.duration * 100),
                    'duration': t.duration,
                    'current_time': Math.round(t.currentTime * 10) / 10,
                    'dataset': t.dataset
                };
            }
        }
    }, {
        key: 'getF',
        value: function getF(f, e, t, pl) {
            var n = t.name || t.id || '-';
            var l = 0;
            if (t.tagName.toLowerCase() === 'select') {
                var a = [];
                for (var i = 0; i < t.length; i++) {
                    if (t[i].selected) {
                        a.push(true);
                    }
                }
                l = a.length;
            } else if (t.tagName.toLowerCase() === 'input' && (t.type === 'checkbox' || t.type === 'radio')) {
                if (t.checked) {
                    l = 1;
                } else {
                    l = 0;
                }
            } else {
                l = t.value.length;
            }
            if (t.type !== 'hidden') {
                f.items_detail[n] = {
                    'status': e,
                    'length': l
                };
            }
            if (!f.first_item) {
                f.first_item = t.name || t.id || '-';
                f.first_item_since_page_load = (Date.now() - pl) / 1000;
            }
            f.last_item = t.name || t.id || '-';
            f.last_item_since_page_load = (Date.now() - pl) / 1000;
            f.last_item_since_first_item = f.last_item_since_page_load - f.first_item_since_page_load;
            return f;
        }
    }, {
        key: 'getUniqueId',
        value: function getUniqueId() {
            return this.uniqueId;
        }
    }, {
        key: 'buildIngest',
        value: function buildIngest(u, c, s) {
            var igt = {
                'user': u,
                'context': {}
            }; //ingest
            var lyt = 'unknown'; //layout
            if (this.targetWindow.orientation) {
                lyt = Math.abs(this.targetWindow.orientation) === 90 ? 'landscape' : 'portrait';
            }

            for (var i in c) {
                igt.context[i] = c[i];
            }
            for (var _i in s) {
                igt.context[_i] = s[_i];
            }
            var currentTime = new Date();
            igt.user.timezone = currentTime.getTimezoneOffset() / 60 * -1;
            igt.user.timestamp = currentTime.toISOString();
            igt.user.viewport_height = this.targetWindow.innerHeight;
            igt.user.viewport_width = this.targetWindow.innerWidth;
            igt.user.screen_height = this.targetWindow.screen.height;
            igt.user.screen_width = this.targetWindow.screen.width;
            igt.user.layout = lyt;
            return igt;
        }
    }, {
        key: 'compress',
        value: function compress(v) {
            var r = v;
            r = r.replace(/%22%7D%2C%22/g, '%z');
            r = r.replace(/%22%3A%22/g, '%y');
            r = r.replace(/%22%2C%22/g, '%x');
            r = r.replace(/%22%3A%7B/g, '%w');
            r = r.replace(/%22%3A/g, '%v');
            r = r.replace(/%2C%22/g, '%u');
            r = r.replace(/%7D%7D%7D/g, '%t');
            return r;
        }
    }, {
        key: 'xhr',
        value: function xhr(u, a) {
            var x = null;
            if (this.targetWindow.XDomainRequest) {
                x = new XDomainRequest();
                x.ontimeout = function () {};
                x.onprogress = function () {};
                x.onerror = function () {};
            } else {
                x = new XMLHttpRequest();
            }

            x.open('GET', u, a);
            if (a === true) {
                x.timeout = atlasBeaconTimeout;
            }
            x.withCredentials = true;

            try {
                x.send();
            } catch (e) {}
        }
    }, {
        key: 'transmit',
        value: function transmit(ac, ca, ur, ct, sp) {
            var now = Date.now();
            var a = !(ac === 'unload' && ca === 'page'); //async
            var f = 1; //fpcStatus
            if (this.getC(atlasCookieName) !== atlasId) {
                f = 0;
            }

            var b = JSON.stringify(this.buildIngest(ur, ct, sp));
            var u = 'https://' + atlasEndpoint + '/' + SDK_NAME + '-' + SDK_VERSION + '/' + now + '/' + encodeURIComponent(atlasId) + '/' + f + ('/ingest?k=' + atlasApiKey + '&a=' + ac + '&c=' + ca + '&aqe=%') + ('&d=' + this.compress(encodeURIComponent(b))); //endpointUrl

            if ('sendBeacon' in navigator && sendBeaconStatus === true) {
                try {
                    sendBeaconStatus = navigator.sendBeacon(u, null);
                } catch (e) {
                    sendBeaconStatus = false;
                }
                if (!sendBeaconStatus) {
                    this.xhr(u, a);
                }
                return true;
            } else {
                var targetWindow = this.targetWindow;
                if ('fetch' in targetWindow && typeof targetWindow.fetch === 'function' && 'AbortController' in targetWindow && typeof targetWindow.AbortController === 'function') {
                    var controller = new targetWindow.AbortController();
                    var signal = controller.signal;
                    setTimeout(function () {
                        return controller.abort();
                    }, atlasBeaconTimeout);
                    try {
                        this.targetWindow.fetch(u, { signal: signal, method: 'GET', cache: 'no-store', keepalive: true });
                    } catch (e) {}
                } else {
                    this.xhr(u, a);
                }
                return true;
            }
        }
    }]);

    return Utils;
}();

exports.default = Utils;

},{}]},{},[1]);
